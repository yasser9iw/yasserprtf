// script.js

// Mode clair/sombre
document.getElementById('toggle-mode').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
});

// Boutons "Voir plus" pour les projets
const voirPlusButtons = document.querySelectorAll('.voir-plus');

voirPlusButtons.forEach(button => {
    button.addEventListener('click', function() {
        const details = this.nextElementSibling;
        if (details.style.display === 'block') {
            details.style.display = 'none';
            this.textContent = 'Voir plus';
        } else {
            details.style.display = 'block';
            this.textContent = 'Voir moins';
        }
    });
});
